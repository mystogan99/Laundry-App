/*
 Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang("placeholder","nl",{title:"Eigenschappen placeholder",toolbar:"Placeholder aanmaken",name:"Naam placeholder",invalidName:"De placeholder mag niet leeg zijn, en mag niet een van de volgende tekens bevatten: [, ], \x3c, \x3e",pathName:"placeholder"});